#ifndef PLAYER_H
#define PLAYER_H

#include "environment.h"

class Player{
    public:
      Player(int jug);
      Environment::ActionType Think();
      void Perceive(const Environment &env);
      double MiniMax(const Environment & T, int jugador, int limite, int &accion);
      double Poda_AlfaBeta(const Environment & T, int jugador , int prof, int &accion, double alpha, double beta);
    private:
      int jugador_;
      Environment actual_;
};
#endif
