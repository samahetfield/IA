#include <iostream>
#include <cstdlib>
#include <vector>
#include <queue>
#include "player.h"
#include "environment.h"

using namespace std;

const double masinf=9999999999.0, menosinf=-9999999999.0;


// Constructor
Player::Player(int jug){
    jugador_=jug;
}

// Actualiza el estado del juego para el jugador
void Player::Perceive(const Environment & env){
    actual_=env;
}

double Puntuacion(int jugador, const Environment &estado){
    double suma=0;

    for (int i=0; i<7; i++)
      for (int j=0; j<7; j++){
         if (estado.See_Casilla(i,j)==jugador){
            if (j<3)
               suma += j;
            else
               suma += (6-j);
         }
      }

    return suma;
}


// Funcion de valoracion para testear Poda Alfabeta
double ValoracionTest(const Environment &estado, int jugador){
    int ganador = estado.RevisarTablero();

    if (ganador==jugador)
       return 99999999.0; // Gana el jugador que pide la valoracion
    else if (ganador!=0)
            return -99999999.0; // Pierde el jugador que pide la valoracion
    else if (estado.Get_Casillas_Libres()==0)
            return 0;  // Hay un empate global y se ha rellenado completamente el tablero
    else
          return Puntuacion(jugador,estado);
}

// ------------------- Los tres metodos anteriores no se pueden modificar

double Heuristica(Environment estado,int jugador)
{
    double resultado=5000;
    int oponente;
    int fichasmias, fichas_oponente;
    if(jugador == 1)
        oponente = 2;
    else
        oponente = 1;
    for(int i=0; i<7; ++i){
        for(int j=0; j<7; ++j){
            //Comprobamos que se este mirando una casilla del jugador
            // para ahorrarnos el resto de ifs en caso contrario.
            if(estado.See_Casilla(i,j)==jugador){
                fichasmias++;
                //Damos por malo a las columnas centrales o las laterales
                if(j==3)
                    resultado-=50;
                if(j==0 || j== 6)
                    resultado -= 20;

                
//--------------Combinaciones de dos-----------------------------------------//
                //Horizontal de dos
                if(j<6 && estado.See_Casilla(i,j+1) == jugador)
                    resultado -= 10;
                //Horizontal de dos en el centro
                if(j>1 && j<4 && estado.See_Casilla(i,j+1) == jugador)
                    resultado -= 20;

                //Vertical  de dos
                if(i>0 && estado.See_Casilla(i-1,j) == jugador)
                    resultado -= 5;
                //Vertical de dos resto de columnas
                if(i>0 && i<5 && estado.See_Casilla(i-1,j) == jugador)
                    resultado -= 5;
                //Vertical de dos central
                if(i>0 && j==3 && estado.See_Casilla(i-1,j) == jugador)
                    resultado -= 10;

                //Diagonal derecha abajo de dos
                if((i>0 && j<6) && estado.See_Casilla(i-1,j+1) == jugador)
                    resultado -= 20;
                
                if((i>2 && j<4) && estado.See_Casilla(i-1,j+1) == jugador)
                    resultado -= 20;

                //Diagonal izquierda abajo de dos
                if((i>0 && j>0) && estado.See_Casilla(i-1,j-1) == jugador)
                    resultado -= 20;

                if((i>2 && j>2) && estado.See_Casilla(i-1,j-1) == jugador)
                    resultado -= 20;

//--------------Combinaciones de tres------------------------------------------//
                //Horizontal de tres
                if(j<5 && estado.See_Casilla(i,j+1) == jugador && estado.See_Casilla(i,j+2) == jugador){
                    resultado -= 500;

                    if((j<4 && j>0) && estado.See_Casilla(i,j+3)==0 && estado.See_Casilla(i,j-1)==0)
                       resultado -= 500;
                    else if((j==0) && estado.See_Casilla(i,j+3)==0){
                       resultado -= 500;
                    }
                }
                //Horizontal de tres central
                if(j>0 && j<4 &&  estado.See_Casilla(i,j+1) == jugador && estado.See_Casilla(i,j+2) == jugador){
                        resultado -=500;
                    if(estado.See_Casilla(i,j+3)==0 && estado.See_Casilla(i,j-1)==0)
                       resultado -= 500;
                }

                //Vertical de tres
                if(i>1 &&  estado.See_Casilla(i-1,j) == jugador && estado.See_Casilla(i-2,j) == jugador){
                    resultado -= 500;
                    if((i<6) && estado.See_Casilla(i+1,j)==0)
                        resultado-=500;
                }

                if(i>1 && i<6 &&  estado.See_Casilla(i-1,j) == jugador && estado.See_Casilla(i-2,j) == jugador)
                {
                    resultado -= 500;
                    if(estado.See_Casilla(i+1,j)==0)
                        resultado-=500;
                }
                //Vertical de tres central
                if(i>1 && j==3 &&  estado.See_Casilla(i-1,j) == jugador && estado.See_Casilla(i-2,j) == jugador)
                    resultado -= 500;

                //Diagonal derecha abajo de tres
                if((i>1 && j<5) &&  estado.See_Casilla(i-1,j+1) == jugador && estado.See_Casilla(i-2,j+2) == jugador){
                    resultado -= 500;
                    if((i>2 && j<4 && i<6 && j>0) && estado.See_Casilla(i-3,j+3)==0 && estado.See_Casilla(i+1,j-1)==0)
                        resultado -= 500;
                }
                //Diagonal derecha abajo de tres preferente
                if((i>2 && j<4) && estado.See_Casilla(i-1,j+1) == jugador && estado.See_Casilla(i-2,j+2) == jugador)
                {
                    resultado-= 500;
                    if(i<6 && j>0 && estado.See_Casilla(i-3,j+3)==0 && estado.See_Casilla(i+1,j-1)==0)
                        resultado -= 500;
                }

                //Diagonal izq abajo de tres
                if((i>1 && j>1) && estado.See_Casilla(i-1,j-1) == jugador && estado.See_Casilla(i-2,j-2) == jugador){
                    resultado -= 500;
                    if((i<6 && j<6 && i>2 && j>2) && estado.See_Casilla(i+1,j+1)==0 && estado.See_Casilla(i-3,j-3)==0)
                        resultado -= 500;
                }
                if((i>2 && j>2) && estado.See_Casilla(i-1,j-1) == jugador && estado.See_Casilla(i-2,j-2) == jugador)
                {
                    resultado -= 500;
                    //Diagonal izq abajo de tres preferente con hueco en ambos lados
                    if(i<6 && j<6 && estado.See_Casilla(i+1,j+1)==0 && estado.See_Casilla(i-3,j-3)==0)
                        resultado -= 500;
                }

                if(j<6 && estado.See_Casilla(i,j+1) == oponente)
                    resultado -= 50;
                if(i<6 && estado.See_Casilla(i+1,j) == oponente)
                    resultado -= 50;
                if(i>0 && estado.See_Casilla(i-1,j) == oponente)
                    resultado -= 50;
                if(j>0 && estado.See_Casilla(i,j-1) == oponente)
                    resultado -= 50;

            }
       /*     else if(estado.See_Casilla(i,j) == oponente)
                fichas_oponente++;
        */}
    }

   /* if(fichasmias > fichas_oponente)
        resultado -= 1000;
    */return resultado;
}


// Funcion heuristica (ESTA ES LA QUE TENEIS QUE MODIFICAR)
double Valoracion(const Environment &estado, int jugador){
    int ganador = estado.RevisarTablero();
    if (ganador==jugador)
        return 99999999.0; // Gana el jugador que pide la valoracion
    else if (ganador!=0)
        return -99999999.0; // Pierde el jugador que pide la valoracion
    else if (estado.Get_Casillas_Libres()==0)
        return 0;  // Hay un empate global y se ha rellenado completamente el tablero
    else{
        //Si no he ganado ni perdido ni empatado aplicamos la heurística
        double total=0;
        total = Heuristica(estado,jugador);
        return total;
    }
}

// Esta funcion no se puede usar en la version entregable
// Aparece aqui solo para ILUSTRAR el comportamiento del juego
// ESTO NO IMPLEMENTA NI MINIMAX, NI PODA ALFABETA
void JuegoAleatorio(bool aplicables[], int opciones[], int &j){
    j=0;
    for (int i=0; i<8; i++){
        if (aplicables[i]){
           opciones[j]=i;
           j++;
        }
    }
}






// Invoca el siguiente movimiento del jugador
Environment::ActionType Player::Think(){
    const int PROFUNDIDAD_MINIMAX = 6;  // Umbral maximo de profundidad para el metodo MiniMax
    const int PROFUNDIDAD_ALFABETA = 8; // Umbral maximo de profundidad para la poda Alfa_Beta

    Environment::ActionType accion; // acción que se va a devolver
    bool aplicables[8]; // Vector bool usado para obtener las acciones que son aplicables en el estado actual. La interpretacion es
                        // aplicables[0]==true si PUT1 es aplicable
                        // aplicables[1]==true si PUT2 es aplicable
                        // aplicables[2]==true si PUT3 es aplicable
                        // aplicables[3]==true si PUT4 es aplicable
                        // aplicables[4]==true si PUT5 es aplicable
                        // aplicables[5]==true si PUT6 es aplicable
                        // aplicables[6]==true si PUT7 es aplicable
                        // aplicables[7]==true si BOOM es aplicable



    double valor; // Almacena el valor con el que se etiqueta el estado tras el proceso de busqueda.
    double alpha, beta; // Cotas de la poda AlfaBeta

    int n_act; //Acciones posibles en el estado actual


    n_act = actual_.possible_actions(aplicables); // Obtengo las acciones aplicables al estado actual en "aplicables"
    int opciones[10];

    // Muestra por la consola las acciones aplicable para el jugador activo
    //actual_.PintaTablero();
    cout << " Acciones aplicables ";
    (jugador_==1) ? cout << "Verde: " : cout << "Azul: ";
    for (int t=0; t<8; t++)
      if (aplicables[t])
         cout << " " << actual_.ActionStr( static_cast< Environment::ActionType > (t)  );
    cout << endl;


    //--------------------- COMENTAR Desde aqui
/*
    cout << "\n\t";
    int n_opciones=0;
    JuegoAleatorio(aplicables, opciones, n_opciones);

    if (n_act==0){
      (jugador_==1) ? cout << "Verde: " : cout << "Azul: ";
      cout << " No puede realizar ninguna accion!!!\n";
      //accion = Environment::actIDLE;
    }
    else if (n_act==1){
           (jugador_==1) ? cout << "Verde: " : cout << "Azul: ";
            cout << " Solo se puede realizar la accion "
                 << actual_.ActionStr( static_cast< Environment::ActionType > (opciones[0])  ) << endl;
            accion = static_cast< Environment::ActionType > (opciones[0]);

         }
         else { // Hay que elegir entre varias posibles acciones
            int aleatorio = rand()%n_opciones;
            cout << " -> " << actual_.ActionStr( static_cast< Environment::ActionType > (opciones[aleatorio])  ) << endl;
            accion = static_cast< Environment::ActionType > (opciones[aleatorio]);
         }
*/
    //--------------------- COMENTAR Hasta aqui


    //--------------------- AQUI EMPIEZA LA PARTE A REALIZAR POR EL ALUMNO ------------------------------------------------

    

    // Opcion: Poda AlfaBeta
    // NOTA: La parametrizacion es solo orientativa
    // valor = Poda_AlfaBeta(actual_, jugador_, 0, PROFUNDIDAD_ALFABETA, accion, alpha, beta);
    //cout << "Valor MiniMax: " << valor << "  Accion: " << actual_.ActionStr(accion) << endl;

    int acc_act = -1;
    alpha = menosinf;
    beta = masinf;

    //  MiniMax(actual_, jugador_, PROFUNDIDAD_MINIMAX, acc_act);
    valor = Poda_AlfaBeta(actual_, jugador_, PROFUNDIDAD_ALFABETA, acc_act, alpha, beta);
    accion = static_cast <Environment::ActionType>(acc_act);
    cout << "Valor PodaAlfaBeta: " << valor << "  Accion: " << actual_.ActionStr(accion) << "Jugador: " << jugador_ << endl;

    return accion;
}

double Player::MiniMax(const Environment & T, int jugador, int limite, int &accion){  // Descomponer prof en prof y limite,
    double Max = menosinf;
    double Min = masinf;

    if(limite == 0){ // Y nodos terminales
        return ValoracionTest(T, jugador);
        cout << "accion = " << accion << endl;
    }
    else{
        double valor = 0;
        int ultact = -1, kk;
        // 0 ficha en columna 1
        // 7 ha explotado la bomba
        // 8 no hay mas acciones
        Environment hijo = T.GenerateNextMove (ultact);

        while(ultact < 8){
            valor = MiniMax(hijo, jugador, limite-1, kk);
            if(limite%2 == 0) {
                if(valor >= Max){
                    Max = valor;
                    accion = ultact;
                }
                 hijo = T.GenerateNextMove (ultact);
            }
            else{
                if(valor < Min){
                    Min = valor;
                    accion = ultact;
                }
                hijo = T.GenerateNextMove (ultact);
            }
            
            if(limite%2 == 0)
                return Max;
            else
                return Min;
        }

       }
}

double Player::Poda_AlfaBeta(const Environment & T, int jugador, int prof, int &accion, double alpha, double beta){
    double Max = menosinf;
    double Min = masinf;

    if(prof == 0){ // Y nodos terminales
        int val = 0;
        val =Valoracion(T, jugador);
        return val;
    }
    else{
        double valor = 0;
        int ultact = -1, kk;
        // 0 ficha en columna 1
        // 7 ha explotado la bomba
        // 8 no hay mas acciones
        Environment hijo = T.GenerateNextMove (ultact);

        while(ultact < 8){
            valor = Poda_AlfaBeta(hijo, jugador, prof-1, kk, alpha, beta);
            if(prof%2 == 0) {
                alpha = max(valor,alpha);
                if(beta <= alpha){
                    return alpha;
                }
                if(valor > Max){
                    Max = valor;
                    accion = ultact;
                }
                hijo = T.GenerateNextMove (ultact);

            }
            else{
                beta = min(valor, beta);
                if(alpha >= beta){
                    return beta;   
                }
                if(valor < Min){
                    Min = valor;
                    accion = ultact;
                }
                 hijo = T.GenerateNextMove (ultact);

            }
        }
            if(prof%2 == 0)
                return Max;
            else
                return Min;
    } 
}
