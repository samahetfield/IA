#include "belkan.h"
#include "conexion.h"
#include "environment.h"
#include <iostream>
#include <cstdlib>
#include <vector>
#include <utility>
#include <cstring>
#include <string>

using namespace std;



// -----------------------------------------------------------
void PasarVectoraMapaCaracteres(int fila, int columna, char m[200][200], char *v, int brujula){
  m[fila][columna]=v[0];

    switch(brujula){
        case 0: // Orientacion Norte

		m[fila-1][columna]=v[1];
		for (int i=0; i<3; i++){
		  m[fila-2][columna+i-1]=v[2+i];
		}
		for (int j=0; j<5; j++){
		  m[fila-3][columna+j-2]=v[5+j];
		}
	        break;
	case 1: // Orientacion Este
		m[fila][columna+1]=v[1];
		for (int i=0; i<3; i++){
		  m[fila+i-1][columna+2]=v[2+i];
		}
		for (int j=0; j<5; j++){
		  m[fila+j-2][columna+3]=v[5+j];
		}
	        break;
        case 2: // Orientacion Sur
		m[fila+1][columna]=v[1];
		for (int i=0; i<3; i++){
		  m[fila+2][columna+1-i]=v[2+i];
		}
		for (int j=0; j<5; j++){
		  m[fila+3][columna+2-j]=v[5+j];
		}
		                break;
        case 3: // Orientacion Oeste
		m[fila][columna-1]=v[1];
		for (int i=0; i<3; i++){
		  m[fila+1-i][columna-2]=v[2+i];
		}
		for (int j=0; j<5; j++){
		  m[fila+2-j][columna-3]=v[5+j];
		}

                break;
    }

}


// -----------------------------------------------------------
void Agent::Perceive(Environment &env)
{
	env.SenSorStatus(VISTA_, SURFACE_, MENSAJE_, REINICIADO_, EN_USO_, MOCHILLA_, PUNTUACION_, FIN_JUEGO_, SALUD_, false);

}


bool Agent::Perceive_Remote(conexion_client &Cliente, Environment &env)
{
	bool actualizado=false;


	actualizado = env.Perceive_Remote(Cliente);
	if (actualizado)
		env.SenSorStatus(VISTA_, SURFACE_, MENSAJE_, REINICIADO_, EN_USO_, MOCHILLA_, PUNTUACION_, FIN_JUEGO_, SALUD_, true);

    return actualizado;
}


// -----------------------------------------------------------
string ActionStr(Agent::ActionType accion)
{
	switch (accion)
	{
	case Agent::actFORWARD: return "FORWARD";
	case Agent::actTURN_L: return "TURN LEFT";
	case Agent::actTURN_R: return "TURN RIGHT";
	case Agent::actIDLE: return "IDLE";
	case Agent::actPICKUP: return "PICK UP";
	case Agent::actPUTDOWN: return "PUT DOWN";
	case Agent::actPUSH: return "PUSH";
	case Agent::actPOP: return "POP";
	case Agent::actGIVE: return "GIVE";
	case Agent::actTHROW: return "THROW";
	default: return "????";
	}
}

// -----------------------------------------------------------
void Agent::ActualizarInformacion(Environment *env){
	// Actualizar mi informacion interna
	if (REINICIADO_){
		// Lo que tengas que hacer si eres reposicionado en el juego
        for(int i=0 ; i<200; i++)
            for(int j=0; j<200; j++){
                mapa_entorno_[i][j] = '?';
                mapa_objetos_[i][j] = '?';
                mapavisto_[i][j] = 0;
            }
        x_ = 99;
        y_ = 99;
        orientacion_=3;
        cordx1 = 0;
        cordy1 = 0;
        cordx2 = 0;
        cordy2 = 0;
        conteste = 0;
		contnorte = 0;
		contoeste = 0;
		contsur = 0;
        tok = false;
        tr = false;
        tl = false;
        td = false;
	}

	switch(last_accion_){
	  case 0: //avanzar
	  switch(orientacion_){
	    case 0: // norte
		    y_--;
		    break;
	    case 1: // este
		    x_++;
		    break;
	    case 2: // sur
		    y_++;
		    break;
	    case 3: // oeste
		    x_--;
		    break;
	  }
	  break;
	  case 1: // girar izq
		  orientacion_=(orientacion_+3)%4;
		  break;
	  case 2: // girar dch
		  orientacion_=(orientacion_+1)%4;
		  break;
	}

	// Comprobacion para no salirme del rango del mapa
	bool algo_va_mal=false;
	if (y_<0){
		y_=0;
		algo_va_mal=true;
	}
	else if (y_>199){
		y_=199;
		algo_va_mal=true;
	}
	if (x_<0){
		x_=0;
		algo_va_mal=true;
	}
	else if (x_>199){
		x_=199;
		algo_va_mal=true;
	}

	if (algo_va_mal){
		cout << "CUIDADO: NO ESTAS CONTROLANDO BIEN LA UBICACION DE TU AGENTE\n";
	}


	PasarVectoraMapaCaracteres(y_,x_,mapa_entorno_,VISTA_,orientacion_);
	PasarVectoraMapaCaracteres(y_,x_,mapa_objetos_,SURFACE_,orientacion_);

	env->ActualizarMatrizUsuario(mapa_entorno_);

}

// -----------------------------------------------------------
Agent::ActionType Agent::Think()
{
	Agent::ActionType accion = actFORWARD; // Por defecto avanza
    int aleatorio;
    bool vistos2K;
	// tomar accion

    if(EN_USO_ == '6'){                                                                        // Si estan en uso las zapatillas
         if(VISTA_[1] == 'P' || VISTA_[1] == 'M' || VISTA_[1] == 'A' || VISTA_[1] == 'D'){
            aleatorio = rand() % 2 + 1;                                                         // Giro aleatoriamente
            if(aleatorio == 1){
                accion = actTURN_L;
            }
            else if(aleatorio == 2){
                accion = actTURN_R;

            }
        }
        // Compruebo cual es la casilla menos pisada y voy hacia ella
        else{
            if(orientacion_ == 0 && mapavisto_[x_][y_] < mapavisto_[x_][y_-1] ){
                aleatorio = rand() % 3;
                if(aleatorio == 1){
                    accion = actTURN_L;
                }
                else if(aleatorio == 2){
                    accion = actTURN_R;
                }
                else accion = actFORWARD;
            }
            else if(orientacion_ == 1 && mapavisto_[x_][y_] < mapavisto_[x_+1][y_-1] ){
                        aleatorio = rand() % 3;
                if(aleatorio == 1){
                    accion = actTURN_L;
                }
                else if(aleatorio == 2){
                    accion = actTURN_R;

                } else accion = actFORWARD;
            }
            else if(orientacion_ == 2 && mapavisto_[x_][y_] < mapavisto_[x_][y_+1] ){
                        aleatorio = rand() % 3;
                if(aleatorio == 1){
                    accion = actTURN_L;
                }
                else if(aleatorio == 2){
                    accion = actTURN_R;
                } else accion = actFORWARD;
            }
            else if(orientacion_ == 3 && mapavisto_[x_][y_] < mapavisto_[x_-1][y_] ){
                        aleatorio = rand() % 3;
                if(aleatorio == 1){
                    accion = actTURN_L;
                }
                else if(aleatorio == 2){
                    accion = actTURN_R;

                } else accion = actFORWARD;
            }
        }


    }
    else if(EN_USO_ == '0'){
         if(VISTA_[1] == 'P' || VISTA_[1] == 'M' || VISTA_[1] == 'B' || VISTA_[1] == 'D'){
            aleatorio = rand() % 2 + 1;
            if(aleatorio == 1){
                accion = actTURN_L;
            }
            else if(aleatorio == 2){
                accion = actTURN_R;

            }
        }
        else{
            if(orientacion_ == 0 && mapavisto_[x_][y_] < mapavisto_[x_][y_-1] ){
                aleatorio = rand() % 3;
                if(aleatorio == 1){
                    accion = actTURN_L;
                }
                else if(aleatorio == 2){
                    accion = actTURN_R;
                }
                else accion = actFORWARD;
            }
            else if(orientacion_ == 1 && mapavisto_[x_][y_] < mapavisto_[x_+1][y_-1] ){
                        aleatorio = rand() % 3;
                if(aleatorio == 1){
                    accion = actTURN_L;
                }
                else if(aleatorio == 2){
                    accion = actTURN_R;

                } else accion = actFORWARD;
            }
            else if(orientacion_ == 2 && mapavisto_[x_][y_] < mapavisto_[x_][y_+1] ){
                        aleatorio = rand() % 3;
                if(aleatorio == 1){
                    accion = actTURN_L;
                }
                else if(aleatorio == 2){
                    accion = actTURN_R;
                } else accion = actFORWARD;
            }
            else if(orientacion_ == 3 && mapavisto_[x_][y_] < mapavisto_[x_-1][y_] ){
                        aleatorio = rand() % 3;
                if(aleatorio == 1){
                    accion = actTURN_L;
                }
                else if(aleatorio == 2){
                    accion = actTURN_R;

                } else accion = actFORWARD;
            }
        }


    }
    else if(EN_USO_ == '2'){
         if(VISTA_[1] == 'P' || VISTA_[1] == 'M' || VISTA_[1] == 'A' || VISTA_[1] == 'B'){
            aleatorio = rand() % 2 + 1;
            if(aleatorio == 1){
                accion = actTURN_L;
            }
            else if(aleatorio == 2){
                accion = actTURN_R;

            }
        }
        else{
            if(orientacion_ == 0 && mapavisto_[x_][y_] < mapavisto_[x_][y_-1] ){
                aleatorio = rand() % 3;
                if(aleatorio == 1){
                    accion = actTURN_L;
                }
                else if(aleatorio == 2){
                    accion = actTURN_R;
                }
                else accion = actFORWARD;
            }
            else if(orientacion_ == 1 && mapavisto_[x_][y_] < mapavisto_[x_+1][y_-1] ){
                        aleatorio = rand() % 3;
                if(aleatorio == 1){
                    accion = actTURN_L;
                }
                else if(aleatorio == 2){
                    accion = actTURN_R;

                } else accion = actFORWARD;
            }
            else if(orientacion_ == 2 && mapavisto_[x_][y_] < mapavisto_[x_][y_+1] ){
                        aleatorio = rand() % 3;
                if(aleatorio == 1){
                    accion = actTURN_L;
                }
                else if(aleatorio == 2){
                    accion = actTURN_R;
                } else accion = actFORWARD;
            }
            else if(orientacion_ == 3 && mapavisto_[x_][y_] < mapavisto_[x_-1][y_] ){
                        aleatorio = rand() % 3;
                if(aleatorio == 1){
                    accion = actTURN_L;
                }
                else if(aleatorio == 2){
                    accion = actTURN_R;

                } else accion = actFORWARD;
            }
        }


    }
    else{
        if(VISTA_[1] == 'B' || VISTA_[1] == 'P' || VISTA_[1] == 'M' || VISTA_[1] == 'A' || VISTA_[1] == 'D'){
            aleatorio = rand() % 2 + 1;
            if(aleatorio == 1){
                accion = actTURN_L;
            }
            else if(aleatorio == 2){
                accion = actTURN_R;

            }
        }
        else{
            if(orientacion_ == 0 && mapavisto_[x_][y_] < mapavisto_[x_][y_-1] ){
                aleatorio = rand() % 3;
                if(aleatorio == 1){
                    accion = actTURN_L;
                }
                else if(aleatorio == 2){
                    accion = actTURN_R;
                }
                else accion = actFORWARD;
            }
            else if(orientacion_ == 1 && mapavisto_[x_][y_] < mapavisto_[x_+1][y_-1] ){
                        aleatorio = rand() % 3;
                if(aleatorio == 1){
                    accion = actTURN_L;
                }
                else if(aleatorio == 2){
                    accion = actTURN_R;

                } else accion = actFORWARD;
            }
            else if(orientacion_ == 2 && mapavisto_[x_][y_] < mapavisto_[x_][y_+1] ){
                        aleatorio = rand() % 3;
                if(aleatorio == 1){
                    accion = actTURN_L;
                }
                else if(aleatorio == 2){
                    accion = actTURN_R;
                } else accion = actFORWARD;
            }
            else if(orientacion_ == 3 && mapavisto_[x_][y_] < mapavisto_[x_-1][y_] ){
                        aleatorio = rand() % 3;
                if(aleatorio == 1){
                    accion = actTURN_L;
                }
                else if(aleatorio == 2){
                    accion = actTURN_R;

                } else accion = actFORWARD;
            }
        }
    }

    // Si tengo delante algún personaje cambio mi direccion
    if(SURFACE_[1] >= 'a' && SURFACE_[1] <= 'z'){
        aleatorio = rand() % 2 + 1;
        if(aleatorio == 1){
            accion = actTURN_L;
        }
        else if(aleatorio == 2){
            accion = actTURN_R;

        }else{
            accion = actFORWARD;
        }
    }

    // Si estoy en una casilla en la que haya algn objeto
    if(SURFACE_[0] >= '0' && SURFACE_[0] <= '9' && VISTA_[1] != 'B' && VISTA_[1] != 'A' && VISTA_[1] != 'D'){
        if(EN_USO_ == '-' && MOCHILLA_[3] == '-'){
            accion = actPICKUP;
        }
        else if(EN_USO_ != '-' && MOCHILLA_[2] == '-'){
            accion = actPUSH;
        }
    }

    // Si delante dengo bosque,agua o puerta, si tengo algún objeto con el que pueda pasar por ellos me lo pongo
    if(VISTA_[1] == 'B'){
        if(EN_USO_ == '-'){
            if(MOCHILLA_[0] == '6' || MOCHILLA_[1] == '6' || MOCHILLA_[2] == '6' || MOCHILLA_[3] == '6'){
                accion = actPOP;
            }
        }
        else if ((EN_USO_ >= '0' && EN_USO_ < '6') || (EN_USO_ >='7' && EN_USO_ <='9')){
            accion = actPUSH;
        }
    }
    else if(VISTA_[1] == 'A'){
        if(EN_USO_ == '-'){
            if(MOCHILLA_[0] == '0' || MOCHILLA_[1] == '0' || MOCHILLA_[2] == '0' || MOCHILLA_[3] == '0'){
                accion = actPOP;
            }
        }
        else if (EN_USO_ >= '1' && EN_USO_ <= '9'){
            accion = actPUSH;
        }
    }
        if(VISTA_[1] == 'D'){
        if(EN_USO_ == '-'){
            if(MOCHILLA_[0] == '2' || MOCHILLA_[1] == '2' || MOCHILLA_[2] == '2' || MOCHILLA_[3] == '2'){
                accion = actPOP;
            }
        }
        else if ((EN_USO_ >= '0' && EN_USO_ < '2') || (EN_USO_ >='3' && EN_USO_ <='9')){
            accion = actPUSH;
        }
    }

    // Le entrego al personaje los objetos
    if(SURFACE_[1] >= 'a' && SURFACE_[1] <= 'z'){
        if((EN_USO_ != '-') && (EN_USO_ != '0') && (EN_USO_ != '2') && (EN_USO_ != '6')){
            accion = actGIVE;
        }
        else if(EN_USO_ == '-'){
            if((MOCHILLA_[0] != '0' && MOCHILLA_[0] != '2' && MOCHILLA_[0] != '6' && MOCHILLA_[0] != '-') || (MOCHILLA_[1] != '0' && MOCHILLA_[1] != '2' && MOCHILLA_[1] != '6' && MOCHILLA_[1] != '-') || (MOCHILLA_[2] != '0' && MOCHILLA_[2] != '2' && MOCHILLA_[2] != '6' && MOCHILLA_[2] != '-')  || (MOCHILLA_[3] != '0' && MOCHILLA_[3] != '2' && MOCHILLA_[3] != '6') && MOCHILLA_[3] != '-')
                accion = actPOP;
            else{
                aleatorio = rand() % 2 + 1;
                if(aleatorio == 1){
                    accion = actTURN_L;
                }
                else if(aleatorio == 2){
                    accion = actTURN_R;
                }else{
                    accion = actFORWARD;
                }
            }
        }
        else if((EN_USO_ == '0') || (EN_USO_ == '2') || (EN_USO_ == '6')){
            accion = actPUSH;
        }
    }

    // Si dentro de vista hay algun oso, me giro
    if(SURFACE_[1] == 'q' || SURFACE_[2] == 'q' || SURFACE_[3] == 'q' || SURFACE_[4] == 'q' || SURFACE_[5] == 'q' || SURFACE_[6] == 'q' || SURFACE_[7] == 'q' || SURFACE_[8] == 'q' || SURFACE_[9] == 'q'){
        accion = actTURN_L;
    }


    // Si estoy en un PK cojo las coordenadas de este
    if(VISTA_[0] == 'K'){
        if(cordx1 ==0 && cordy1 == 0){
            CapturaFilaColumnaPK(MENSAJE_, cordx1, cordy1);
        }
        else if (cordx1 != x_ && cordy1 != y_ && cordx2 == 0 && (last_accion_ == actFORWARD)){
            CapturaFilaColumnaPK(MENSAJE_,cordx2,cordy2);
            for(int i=0; i<100 ; i++){
                for(int j=0; j<100; j++)
                    mapavisto_[i][j] = 0;
            }
            if(cordx1 == cordx2 && cordy1 == cordy2){ // No puede ser el mismo PK que cojí anteriormente
                cordx2 = 0;
                cordy2 = 0;
                vistos2K = false;
            }
            else if((cordx1-cordx2) == 0  || (cordy1-cordy2) == 0){ // No puede estar en la misma fila o la misma columna
                cordx2 = 0;
                cordy2 = 0;
                vistos2K = false;
            }
            else{
                vistos2K = true;
            }
        }
    }

    //Contador para ver el recorrido que realiza
    if(cordx1 !=0 && cordy1 != 0){
        if(orientacion_ == 0){
            contnorte++;
        }else if(orientacion_ == 1){
            conteste++;
        }else if(orientacion_ == 2){
            contsur++;
        }
        else if(orientacion_ == 3){
            contoeste++;
        }
    }
    // Compruebo la orientación del mapa
    if(vistos2K){
        cout << contnorte << " " << contsur << " " << contoeste << " " << conteste << endl;
        if(((cordx1 - cordx2) > 0  && (contnorte - contsur) > 0) && ((cordy1 - cordy2) > 0  && (contoeste - conteste) > 0)){
            tok = true;
            cout << "Bien orientado\n";
        }
        if(((cordx1 - cordx2) > 0  && (contnorte - contsur) > 0) && ((cordy1 - cordy2) < 0  && (contoeste - conteste) < 0)){
            tok = true;
            cout << "Bien orientado\n";
        }
        if(((cordx1 - cordx2) < 0  && (contnorte - contsur) < 0) && ((cordy1 - cordy2) < 0  && (contoeste - conteste) < 0)){
            tok = true;
            cout << "Bien orientado\n";
        }
        if(((cordx1 - cordx2) < 0  && (contnorte - contsur) < 0) && ((cordy1 - cordy2) > 0  && (contoeste - conteste) > 0)){
            tok = true;
            cout << "Bien orientado\n";
        }
        if(((cordx1 - cordx2) > 0  && (contnorte - contsur) < 0) && (cordy1 - cordy2) < 0  && ((contoeste - conteste) < 0)){
            tl = true;
            cout << "Giro el mapa 90º a la Izquierda\n";
        }
        if(((cordx1 - cordx2) < 0  && (contnorte - contsur) > 0) && ((cordy1 - cordy2) > 0  && (contoeste - conteste) > 0)){
            tl = true;
            cout << "Giro el mapa 90º a la Izquierda\n";
        }
        if(((cordx1 - cordx2) > 0  && (contnorte - contsur) > 0) && ((cordy1 - cordy2) > 0  && (contoeste - conteste) < 0)){
            tl = true;
            cout << "Giro el mapa 90º a la Izquierda\n";
        }
        if(((cordx1 - cordx2) < 0  && (contnorte - contsur) < 0) && ((cordy1 - cordy2) < 0  && (contoeste - conteste) > 0)){
            tl = true;
            cout << "Giro el mapa 90º a la Izquierda\n";
        }
        if(((cordx1 - cordx2) >0 && (contnorte - contsur) > 0) && ((cordy1 - cordy2) < 0 && (contoeste - conteste) > 0)){
            tr = true;
            cout << "Giro el mapa 90º a la Derecha\n";
        }
        if(((cordx1 - cordx2) <0 && (contnorte - contsur) < 0) && ((cordy1 - cordy2) >0 && (contoeste - conteste) < 0)){
            tr = true;
            cout << "Giro el mapa 90º a la Derecha\n";
        }
        if(((cordx1 - cordx2) <0 && (contnorte - contsur) > 0) && ((cordy1 - cordy2) < 0 && (contoeste - conteste) < 0)){
            tr = true;
            cout << "Giro el mapa 90º a la Derecha\n";
        }
        if(((cordx1 - cordx2) >0 && (contnorte - contsur) < 0) && ((cordy1 - cordy2) >0 && (contoeste - conteste) > 0)){
            tr = true;
            cout << "Giro el mapa 90º a la Derecha\n";
        }
        if(((cordx1 - cordx2) <0 && (contnorte - contsur) > 0) && ((cordy1 - cordy2) >0 && (contoeste - conteste) < 0)){
            td = true;
            cout << "Giro el mapa 180º\n";
        }
        if(((cordx1 - cordx2) <0 && (contnorte - contsur) > 0) && ((cordy1 - cordy2) < 0 && (contoeste - conteste) > 0)){
            td = true;
            cout << "Giro el mapa 180º\n";
        }
        if(((cordx1 - cordx2) >0 && (contnorte - contsur) < 0) && ((cordy1 - cordy2) > 0 && (contoeste - conteste) < 0)){
            td = true;
            cout << "Giro el mapa 180º\n";
        }
        if(((cordx1 - cordx2) >0 && (contnorte - contsur) < 0) && ((cordy1 - cordy2) <0 && (contoeste - conteste) > 0)){
            td = true;
            cout << "Giro el mapa 180º\n";
        }
    }

        // Voy introduciendo en mapa solución lo que voy descubriendo
        if(tok){
            if(orientacion_ == 0){
                mapa_solucion_[cordx2-1][cordy2] = VISTA_[1];
                mapa_solucion_[cordx2-2][cordy2-1] = VISTA_[2];
                mapa_solucion_[cordx2-2][cordy2] = VISTA_[3];
                mapa_solucion_[cordx2-2][cordy2+1] = VISTA_[4];
                mapa_solucion_[cordx2-3][cordy2-2] = VISTA_[5];
                mapa_solucion_[cordx2-3][cordy2-1] = VISTA_[6];
                mapa_solucion_[cordx2-3][cordy2] = VISTA_[7];
                mapa_solucion_[cordx2-3][cordy2+1] = VISTA_[8];
                mapa_solucion_[cordx2-3][cordy2+2] = VISTA_[9];
                if(accion == actFORWARD)
                    cordx2--;
            }else if(orientacion_ == 1){
                mapa_solucion_[cordx2][cordy2+1] = VISTA_[1];
                mapa_solucion_[cordx2-1][cordy2+2] = VISTA_[2];
                mapa_solucion_[cordx2][cordy2+2] = VISTA_[3];
                mapa_solucion_[cordx2+1][cordy2+2] = VISTA_[4];
                mapa_solucion_[cordx2-2][cordy2+3] = VISTA_[5];
                mapa_solucion_[cordx2-1][cordy2+3] = VISTA_[6];
                mapa_solucion_[cordx2][cordy2+3] = VISTA_[7];
                mapa_solucion_[cordx2+1][cordy2+3] = VISTA_[8];
                mapa_solucion_[cordx2+2][cordy2+3] = VISTA_[9];
                if(accion == actFORWARD)
                    cordy2++;
            }else if(orientacion_ == 2){
                mapa_solucion_[cordx2+1][cordy2] = VISTA_[1];
                mapa_solucion_[cordx2+2][cordy2+1] = VISTA_[2];
                mapa_solucion_[cordx2+2][cordy2] = VISTA_[3];
                mapa_solucion_[cordx2+2][cordy2-1] = VISTA_[4];
                mapa_solucion_[cordx2+3][cordy2+2] = VISTA_[5];
                mapa_solucion_[cordx2+3][cordy2+1] = VISTA_[6];
                mapa_solucion_[cordx2+3][cordy2] = VISTA_[7];
                mapa_solucion_[cordx2+3][cordy2-1] = VISTA_[8];
                mapa_solucion_[cordx2+3][cordy2-2] = VISTA_[9];
                if(accion == actFORWARD)
                    cordx2++;
            }else if(orientacion_ == 3){
                mapa_solucion_[cordx2][cordy2-1] = VISTA_[1];
                mapa_solucion_[cordx2+1][cordy2-2] = VISTA_[2];
                mapa_solucion_[cordx2][cordy2-2] = VISTA_[3];
                mapa_solucion_[cordx2-1][cordy2-2] = VISTA_[4];
                mapa_solucion_[cordx2+2][cordy2-3] = VISTA_[5];
                mapa_solucion_[cordx2+1][cordy2-3] = VISTA_[6];
                mapa_solucion_[cordx2][cordy2-3] = VISTA_[7];
                mapa_solucion_[cordx2-1][cordy2-3] = VISTA_[8];
                mapa_solucion_[cordx2-2][cordy2-3] = VISTA_[9];
                if(accion == actFORWARD)
                    cordy2--;
            }
        }
        else if(tl){
            if(orientacion_ == 0){
                mapa_solucion_[cordx2][cordy2-1] = VISTA_[1];
                mapa_solucion_[cordx2+1][cordy2-2] = VISTA_[2];
                mapa_solucion_[cordx2][cordy2-2] = VISTA_[3];
                mapa_solucion_[cordx2-1][cordy2-2] = VISTA_[4];
                mapa_solucion_[cordx2+2][cordy2-3] = VISTA_[5];
                mapa_solucion_[cordx2+1][cordy2-3] = VISTA_[6];
                mapa_solucion_[cordx2][cordy2-3] = VISTA_[7];
                mapa_solucion_[cordx2-1][cordy2-3] = VISTA_[8];
                mapa_solucion_[cordx2-2][cordy2-3] = VISTA_[9];
                if(accion == actFORWARD)
                    cordy2--;
            }else if(orientacion_ == 1){
                mapa_solucion_[cordx2-1][cordy2] = VISTA_[1];
                mapa_solucion_[cordx2-2][cordy2-1] = VISTA_[2];
                mapa_solucion_[cordx2-2][cordy2] = VISTA_[3];
                mapa_solucion_[cordx2-2][cordy2+1] = VISTA_[4];
                mapa_solucion_[cordx2-3][cordy2-2] = VISTA_[5];
                mapa_solucion_[cordx2-3][cordy2-1] = VISTA_[6];
                mapa_solucion_[cordx2-3][cordy2] = VISTA_[7];
                mapa_solucion_[cordx2-3][cordy2+1] = VISTA_[8];
                mapa_solucion_[cordx2-3][cordy2+2] = VISTA_[9];
                if(accion == actFORWARD)
                    cordx2--;
            }else if(orientacion_ == 2){
                mapa_solucion_[cordx2][cordy2+1] = VISTA_[1];
                mapa_solucion_[cordx2-1][cordy2+2] = VISTA_[2];
                mapa_solucion_[cordx2][cordy2+2] = VISTA_[3];
                mapa_solucion_[cordx2+1][cordy2+2] = VISTA_[4];
                mapa_solucion_[cordx2-2][cordy2+3] = VISTA_[5];
                mapa_solucion_[cordx2-1][cordy2+3] = VISTA_[6];
                mapa_solucion_[cordx2][cordy2+3] = VISTA_[7];
                mapa_solucion_[cordx2+1][cordy2+3] = VISTA_[8];
                mapa_solucion_[cordx2+2][cordy2+3] = VISTA_[9];
                if(accion == actFORWARD)
                    cordy2++;
            }else if(orientacion_ == 3){
                mapa_solucion_[cordx2+1][cordy2] = VISTA_[1];
                mapa_solucion_[cordx2+2][cordy2+1] = VISTA_[2];
                mapa_solucion_[cordx2+2][cordy2] = VISTA_[3];
                mapa_solucion_[cordx2+2][cordy2-1] = VISTA_[4];
                mapa_solucion_[cordx2+3][cordy2+2] = VISTA_[5];
                mapa_solucion_[cordx2+3][cordy2+1] = VISTA_[6];
                mapa_solucion_[cordx2+3][cordy2] = VISTA_[7];
                mapa_solucion_[cordx2+3][cordy2-1] = VISTA_[8];
                mapa_solucion_[cordx2+3][cordy2-2] = VISTA_[9];
                if(accion == actFORWARD)
                    cordx2++;
            }
        }
        else if(tr){
            if(orientacion_ == 0){
                mapa_solucion_[cordx2][cordy2+1] = VISTA_[1];
                mapa_solucion_[cordx2-1][cordy2+2] = VISTA_[2];
                mapa_solucion_[cordx2][cordy2+2] = VISTA_[3];
                mapa_solucion_[cordx2+1][cordy2+2] = VISTA_[4];
                mapa_solucion_[cordx2-2][cordy2+3] = VISTA_[5];
                mapa_solucion_[cordx2-1][cordy2+3] = VISTA_[6];
                mapa_solucion_[cordx2][cordy2+3] = VISTA_[7];
                mapa_solucion_[cordx2+1][cordy2+3] = VISTA_[8];
                mapa_solucion_[cordx2+2][cordy2+3] = VISTA_[9];
                if(accion == actFORWARD)
                    cordy2++;
            }else if(orientacion_ == 1){
                mapa_solucion_[cordx2+1][cordy2] = VISTA_[1];
                mapa_solucion_[cordx2+2][cordy2+1] = VISTA_[2];
                mapa_solucion_[cordx2+2][cordy2] = VISTA_[3];
                mapa_solucion_[cordx2+2][cordy2-1] = VISTA_[4];
                mapa_solucion_[cordx2+3][cordy2+2] = VISTA_[5];
                mapa_solucion_[cordx2+3][cordy2+1] = VISTA_[6];
                mapa_solucion_[cordx2+3][cordy2] = VISTA_[7];
                mapa_solucion_[cordx2+3][cordy2-1] = VISTA_[8];
                mapa_solucion_[cordx2+3][cordy2-2] = VISTA_[9];
                if(accion == actFORWARD)
                    cordx2++;
            }else if(orientacion_ == 2){
                mapa_solucion_[cordx2][cordy2-1] = VISTA_[1];
                mapa_solucion_[cordx2+1][cordy2-2] = VISTA_[2];
                mapa_solucion_[cordx2][cordy2-2] = VISTA_[3];
                mapa_solucion_[cordx2-1][cordy2-2] = VISTA_[4];
                mapa_solucion_[cordx2+2][cordy2-3] = VISTA_[5];
                mapa_solucion_[cordx2+1][cordy2-3] = VISTA_[6];
                mapa_solucion_[cordx2][cordy2-3] = VISTA_[7];
                mapa_solucion_[cordx2-1][cordy2-3] = VISTA_[8];
                mapa_solucion_[cordx2-2][cordy2-3] = VISTA_[9];
                if(accion == actFORWARD)
                    cordy2--;
            }else if(orientacion_ == 3){
                mapa_solucion_[cordx2-1][cordy2] = VISTA_[1];
                mapa_solucion_[cordx2-2][cordy2-1] = VISTA_[2];
                mapa_solucion_[cordx2-2][cordy2] = VISTA_[3];
                mapa_solucion_[cordx2-2][cordy2+1] = VISTA_[4];
                mapa_solucion_[cordx2-3][cordy2-2] = VISTA_[5];
                mapa_solucion_[cordx2-3][cordy2-1] = VISTA_[6];
                mapa_solucion_[cordx2-3][cordy2] = VISTA_[7];
                mapa_solucion_[cordx2-3][cordy2+1] = VISTA_[8];
                mapa_solucion_[cordx2-3][cordy2+2] = VISTA_[9];
                if(accion == actFORWARD)
                    cordx2--;
            }
        }
        else if(td){
            if(orientacion_ == 0){
                mapa_solucion_[cordx2+1][cordy2] = VISTA_[1];
                mapa_solucion_[cordx2+2][cordy2+1] = VISTA_[2];
                mapa_solucion_[cordx2+2][cordy2] = VISTA_[3];
                mapa_solucion_[cordx2+2][cordy2-1] = VISTA_[4];
                mapa_solucion_[cordx2+3][cordy2+2] = VISTA_[5];
                mapa_solucion_[cordx2+3][cordy2+1] = VISTA_[6];
                mapa_solucion_[cordx2+3][cordy2] = VISTA_[7];
                mapa_solucion_[cordx2+3][cordy2-1] = VISTA_[8];
                mapa_solucion_[cordx2+3][cordy2-2] = VISTA_[9];
                if(accion == actFORWARD)
                    cordx2++;
            }else if(orientacion_ == 1){
                mapa_solucion_[cordx2][cordy2-1] = VISTA_[1];
                mapa_solucion_[cordx2+1][cordy2-2] = VISTA_[2];
                mapa_solucion_[cordx2][cordy2-2] = VISTA_[3];
                mapa_solucion_[cordx2-1][cordy2-2] = VISTA_[4];
                mapa_solucion_[cordx2+2][cordy2-3] = VISTA_[5];
                mapa_solucion_[cordx2+1][cordy2-3] = VISTA_[6];
                mapa_solucion_[cordx2][cordy2-3] = VISTA_[7];
                mapa_solucion_[cordx2-1][cordy2-3] = VISTA_[8];
                mapa_solucion_[cordx2-2][cordy2-3] = VISTA_[9];
                if(accion == actFORWARD)
                    cordy2--;
            }else if(orientacion_ == 2){
                mapa_solucion_[cordx2-1][cordy2] = VISTA_[1];
                mapa_solucion_[cordx2-2][cordy2-1] = VISTA_[2];
                mapa_solucion_[cordx2-2][cordy2] = VISTA_[3];
                mapa_solucion_[cordx2-2][cordy2+1] = VISTA_[4];
                mapa_solucion_[cordx2-3][cordy2-2] = VISTA_[5];
                mapa_solucion_[cordx2-3][cordy2-1] = VISTA_[6];
                mapa_solucion_[cordx2-3][cordy2] = VISTA_[7];
                mapa_solucion_[cordx2-3][cordy2+1] = VISTA_[8];
                mapa_solucion_[cordx2-3][cordy2+2] = VISTA_[9];
                if(accion == actFORWARD)
                    cordx2--;
            }else if(orientacion_ == 3){
                mapa_solucion_[cordx2][cordy2+1] = VISTA_[1];
                mapa_solucion_[cordx2-1][cordy2+2] = VISTA_[2];
                mapa_solucion_[cordx2][cordy2+2] = VISTA_[3];
                mapa_solucion_[cordx2+1][cordy2+2] = VISTA_[4];
                mapa_solucion_[cordx2-2][cordy2+3] = VISTA_[5];
                mapa_solucion_[cordx2-1][cordy2+3] = VISTA_[6];
                mapa_solucion_[cordx2][cordy2+3] = VISTA_[7];
                mapa_solucion_[cordx2+1][cordy2+3] = VISTA_[8];
                mapa_solucion_[cordx2+2][cordy2+3] = VISTA_[9];
                if(accion == actFORWARD)
                    cordy2++;
            }
        }

    // Si me choco con un personaje, cambio las coordenadas
    if(MENSAJE_.find("chocado") != string::npos){
        if(orientacion_ == 0){
                cordx2++;
        }
        else if(orientacion_ == 1){
                cordy2--;
        }
        else if(orientacion_ == 2){
                cordx2--;
        }
        else if(orientacion_ == 3){
                cordy2++;
        }
    }

    if(pasos == 999){
        cout << "EN USO " << EN_USO_ << endl;
        cout << "MOCHILA " << MOCHILLA_[0] << MOCHILLA_[1] << MOCHILLA_[2] << MOCHILLA_[3] << endl;
        cout << "PUNTUACION " << PUNTUACION_ << endl;
        cout << "---------------------- \n" << endl;

        pasos = 0;
    }

     pasos++;
     mapavisto_[x_][y_]++;

	// recuerdo la ultima accion realizada
	last_accion_ = accion;
	return accion;

}

void Agent::CapturaFilaColumnaPK (string mensaje, int &fila, int &columna){
	if (mensaje.substr(0,8)=="PK fila:"){
		int pos = mensaje.find('c');
		string valor = mensaje.substr(9,pos-8);
		fila = atoi(valor.c_str());

		int pos2 = mensaje.find('.');
		pos = pos+8;
		valor = mensaje.substr(pos,pos2-1);
		columna = atoi(valor.c_str());
	}
}

void Agent::RellenarMatriz(){
        for(int i=97; i<100; i++)
            for(int j=0; j<100; j++)
                mapa_solucion_[i][j] = 'P';
        for(int i=0; i<3; i++)
            for(int j=0; j<100; j++)
                mapa_solucion_[i][j] = 'P';
        for(int i=0; i<100; i++)
            for(int j=97; j<100; j++)
               mapa_solucion_[i][j] = 'P';
        for(int i=0; i<100; i++)
            for(int j=0; j<3; j++)
               mapa_solucion_[i][j] = 'P';
        for(int i=3; i<97; i++)
            for(int j=3; j<97; j++)
                mapa_solucion_[i][j] = 'S';
}

